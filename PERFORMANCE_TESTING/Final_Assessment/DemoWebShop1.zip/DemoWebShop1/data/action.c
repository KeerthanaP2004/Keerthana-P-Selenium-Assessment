Action()
{

	lr_start_transaction("1_Launch_URL");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_custom_request("status.geotrust.com", 
		"URL=http://status.geotrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x04\\x93\\x7F\"j\\xA8\\xB6\\x1C\\xBFO\\xE5\\x8A\\xDF\\xD1\\x82T", 
		LAST);

	web_custom_request("status.geotrust.com_2", 
		"URL=http://status.geotrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x04\\x93\\x7F\"j\\xA8\\xB6\\x1C\\xBFO\\xE5\\x8A\\xDF\\xD1\\x82T", 
		LAST);

	web_custom_request("status.geotrust.com_3", 
		"URL=http://status.geotrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x04\\x93\\x7F\"j\\xA8\\xB6\\x1C\\xBFO\\xE5\\x8A\\xDF\\xD1\\x82T", 
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("styles.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("responsive.css", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/responsive.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("jquery.validate.unobtrusive.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.unobtrusive.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.css", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("jquery-1.10.2.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-1.10.2.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t9.inf", 
		LAST);

	web_url("nivo-slider.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/nivo-slider.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("default.css", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("jquery.validate.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery.validate.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("jquery-ui-1.10.3.custom.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-ui-1.10.3.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_url("jquery-migrate-1.2.1.min.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/jquery-migrate-1.2.1.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t14.inf", 
		LAST);

	web_url("public.common.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.common.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("public.ajaxcart.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.ajaxcart.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("jquery.nivo.slider.js", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Scripts/jquery.nivo.slider.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_125.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_125.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t19.inf", 
		LAST);

	web_url("0000031_build-your-own-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000031_build-your-own-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t20.inf", 
		LAST);

	web_url("logo.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("0000201_build-your-own-expensive-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000201_build-your-own-expensive-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t27.inf", 
		LAST);

	web_url("0000015_25-virtual-gift-card_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000015_25-virtual-gift-card_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t28.inf", 
		LAST);

	web_url("0000204_simple-computer_125.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000204_simple-computer_125.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("0000215.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000215.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("0000240.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t32.inf", 
		LAST);

	web_url("favicon.ico", 
		"URL=https://demowebshop.tricentis.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t33.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_websocket_send("ID=1", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive0*/

	web_concurrent_start(NULL);

	web_url("top-menu-divider.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("bullet-right.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/bullet-right.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t22.inf", 
		LAST);

	web_url("loading.gif", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t23.inf", 
		LAST);

	web_url("star-x-inactive.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("star-x-active.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t25.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("ui-bg_flat_75_ffffff_40x100.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t31.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("top-menu-triangle.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t34.inf", 
		LAST);

	web_url("arrows.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t35.inf", 
		LAST);

	web_url("bullets.png", 
		"URL=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", 
		"Snapshot=t36.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_Launch_URL",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("2_Register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t38.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=MY3_WG4raxrJMH-vZaqbc36KJtXVBmg04AvSCqjGIR4Zy4pHrmZ4ddpkzNtaSipcLDCyd8l9PL-6pFia6RWIGBskDpHeq8oKXTgz-PnwwJY1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value=Ammu", ENDITEM, 
		"Name=LastName", "Value=P", ENDITEM, 
		"Name=Email", "Value=Keertu21@gmail.com", ENDITEM, 
		"Name=Password", "Value=Keertu@2026", ENDITEM, 
		"Name=ConfirmPassword", "Value=Keertu@2026", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t39.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("2_Register",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("3_Search");

	web_url("searchtermautocomplete", 
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=Lap", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t40.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("searchtermautocomplete_2", 
		"URL=https://demowebshop.tricentis.com/catalog/searchtermautocomplete?term=Laptop", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t41.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("ajax_loader_small.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_small.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("ui-bg_glass_75_dadada_1x400.png", 
		"URL=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", 
		"Snapshot=t43.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("search", 
		"URL=https://demowebshop.tricentis.com/search?q=Laptop", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t44.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("3_Search",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("4_Add_to_Cart");

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t45.inf", 
		LAST);

	web_custom_request("1", 
		"URL=https://demowebshop.tricentis.com/addproducttocart/catalog/31/1/1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/search?q=Laptop", 
		"Snapshot=t46.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_concurrent_start(NULL);

	web_url("ico-close-notification-bar.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t47.inf", 
		LAST);

	web_url("0000224_141-inch-laptop_47.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_47.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/search?q=Laptop", 
		"Snapshot=t48.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("4_Add_to_Cart",LR_AUTO);

	lr_think_time(21);

	lr_start_transaction("5_Shopping_Cart");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/search?q=Laptop", 
		"Snapshot=t49.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0000224_141-inch-laptop_80.png", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000224_141-inch-laptop_80.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t50.inf", 
		LAST);

	lr_think_time(11);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790845917615", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t51.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("5_Shopping_Cart",LR_AUTO);

	lr_start_transaction("6_Checkout");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t52.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7121445", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=41", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("public.accordion.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.accordion.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t53.inf", 
		LAST);

	web_url("public.onepagecheckout.js", 
		"URL=https://demowebshop.tricentis.com/Scripts/public.onepagecheckout.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t54.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("6_Checkout",LR_AUTO);

	lr_think_time(21);

	lr_start_transaction("7_Continue");

	web_url("getstatesbycountryid_2", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790845945629", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("top-menu-list-image.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("top-menu-background.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-background.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("top-menu-list-image-hover.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t58.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(20);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value=Ammu", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value=P", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=Keertu21@gmail.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=ballari", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=fgjgbjk", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=583104", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=9638527410", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_url("arrow-up.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/arrow-up.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t60.inf", 
		LAST);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t61.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159716", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=Ammu", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=P", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=Keertu21@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo.jpg", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CashOnDelivery/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t63.inf", 
		LAST);

	web_url("logo.jpg_2", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.Manual/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t64.inf", 
		LAST);

	web_url("logo.jpg_3", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.CheckMoneyOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t65.inf", 
		LAST);

	web_url("logo.jpg_4", 
		"URL=https://demowebshop.tricentis.com/plugins/Payments.PurchaseOrder/logo.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t66.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t67.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("7_Continue",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("8_Confirm");

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t70.inf", 
		"Mode=HTTP", 
		LAST);

	return 0;
}